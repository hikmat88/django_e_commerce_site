from django.shortcuts import render,redirect
from products.models import Product
from django.contrib.auth.decorators import login_required
from .models import Cart
from django.contrib import messages
# Create your views here.

def homepage(request):
    products=Product.objects.all().order_by('-id')[:8]
    context={
        'products':products
    }
    return render(request,'userpage/home.html',context)

def productdetails(request,product_id):
    product=Product.objects.get(id=product_id)
    context={

    'product':product
    }
    return render(request,'userpage/productdetails.html',context)

def show_product(request):
    product=Product.objects.all()
    context={

    'products':product
    }
    return render(request,'userpage/product.html',context)

@login_required
def add_to_cart(request,product_id):
    user=request.user
    product=Product.objects.get(id=product_id)
    check_item_presence=Cart.objects.filter(user=user,product=product)
    if check_item_presence:
        messages.add_message(request,messages.ERROR,'product alredy in the cart')
        return redirect('/products')
    else:
        cart=Cart.objects.create(product=product,user=user)
        if cart:
            messages.add_message(request,messages.SUCCESS,'product added to cart')
            return redirect('/cart')
        else:
            messages.add_message(request,messages.ERROR,'someting went wrong')
            return redirect('/product')
@login_required       
def show_cart_items(request):
    user=request.user
    cart=Cart.objects.filter(user=user)
    context={
        'cart':cart
    }
    return render(request,'userpage/cart.html',context)

@login_required
def delete_cart_item(request,cart_id):
    cart=Cart.objects.get(id=cart_id)
    cart.delete()
    messages.add_message(request,messages.SUCCESS,'cart items is delete')
    return redirect('/cart')


